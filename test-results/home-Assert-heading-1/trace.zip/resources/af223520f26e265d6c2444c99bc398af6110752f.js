// API BASE URL
const DEV_API_BASE_URL = "https://dev.ssa.etondigital.com/api/v1";
const CONVERSION_DEV_URL = DEV_API_BASE_URL + "/conversion";
const HOLYCODE_API_KEY =
  "31d0d4c9f09fcc8a8a333c8b7243478b14b86de9e895e3118da4ddf4f34f6aaf";

// Configuration Constants
const COOKIE_EXPIRATION_DAYS = 2; // Expiration for cookies in days

// Event Types
const EVENT_TYPE = {
  CONTACT_FORM_VIEW: "Contact_Form_View",
  CONTACT_LEAD: "Contact_Lead",
};

// URL Parameters Constants
const UTM_PARAMS = {
  SOURCE: "utm_source",
  MEDIUM: "utm_medium",
  CAMPAIGN: "utm_campaign",
  TERM: "utm_term",
  CONTENT: "utm_content",
};

// Click ID Constants
const CLICK_IDS = {
  GOOGLE: "gclid",
  MICROSOFT: "msclkid",
  FACEBOOK: "fbclid",
  TIKTOK: "ttclid",
  LINKEDIN: "li_fat_id",
  SNAPCHAT: "scclid",
};

// Source and Medium Constants
const SOURCES = {
  GOOGLE: "google",
  BING: "bing",
  FACEBOOK: "facebook",
  INSTAGRAM: "instagram",
  MICROSOFTADS: "microsoftads",
  SNAPCHAT: "snapchat",
  TIKTOK: "tiktok",
  DIRECT: "direct",
  LINKEDIN: "linkedin",
  YAHOO: "yahoo",
  DUCKDUCKGO: "duckduckgo",
  BAIDU: "baidu",
  NZZ_CH: "nzz.ch",
};

const MEDIUMS = {
  ORGANIC: "organic",
  CPC: "cpc",
  PAID: "paid",
  NONE: "none",
  REFERRAL: "referral",
};

// Cookie Names
const COOKIE_NAMES = [
  UTM_PARAMS.SOURCE,
  UTM_PARAMS.MEDIUM,
  UTM_PARAMS.CAMPAIGN,
  UTM_PARAMS.TERM,
  UTM_PARAMS.CONTENT,
  ...Object.values(CLICK_IDS),
  "event_type", // Event type if saved
  "timestamp", // Timestamp for event capture
];

// Helper Functions
function getQueryParam(param) {
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get(param);
}

function getReferrerSourceMedium() {
  const referrer = document.referrer;
  let source = SOURCES.DIRECT;
  let medium = MEDIUMS.NONE;

  if (referrer.includes("google.com")) {
    source = SOURCES.GOOGLE;
    medium = getQueryParam(CLICK_IDS.GOOGLE) ? MEDIUMS.CPC : MEDIUMS.ORGANIC;
  } else if (referrer.includes("bing.com")) {
    source = getQueryParam(CLICK_IDS.MICROSOFT)
      ? SOURCES.MICROSOFTADS
      : SOURCES.BING;
    medium = getQueryParam(CLICK_IDS.MICROSOFT) ? MEDIUMS.CPC : MEDIUMS.ORGANIC;
  } else if (referrer.includes("facebook.com")) {
    source = SOURCES.FACEBOOK;
    medium = getQueryParam(CLICK_IDS.FACEBOOK) ? MEDIUMS.PAID : MEDIUMS.ORGANIC;
  } else if (referrer.includes("instagram.com")) {
    source = SOURCES.INSTAGRAM;
    medium = getQueryParam(CLICK_IDS.FACEBOOK) ? MEDIUMS.PAID : MEDIUMS.ORGANIC;
  } else if (referrer.includes("tiktok.com")) {
    source = SOURCES.TIKTOK;
    medium = getQueryParam(CLICK_IDS.TIKTOK) ? MEDIUMS.PAID : MEDIUMS.ORGANIC;
  } else if (referrer.includes("snapchat.com")) {
    source = SOURCES.SNAPCHAT;
    medium = getQueryParam(CLICK_IDS.SNAPCHAT) ? MEDIUMS.PAID : MEDIUMS.ORGANIC;
  } else if (referrer.includes("linkedin.com")) {
    source = SOURCES.LINKEDIN;
    medium = getQueryParam(CLICK_IDS.LINKEDIN) ? MEDIUMS.PAID : MEDIUMS.ORGANIC;
  } else if (referrer.includes("yahoo.com")) {
    source = SOURCES.YAHOO;
    medium = MEDIUMS.ORGANIC;
  } else if (referrer.includes("duckduckgo.com")) {
    source = SOURCES.DUCKDUCKGO;
    medium = MEDIUMS.ORGANIC;
  } else if (referrer.includes("baidu.com")) {
    source = SOURCES.BAIDU;
    medium = MEDIUMS.ORGANIC;
  } else if (referrer.includes("nzz.ch")) {
    source = SOURCES.NZZ_CH;
    medium = MEDIUMS.REFERRAL;
  } else if (referrer) {
    source = new URL(referrer).hostname;
    medium = MEDIUMS.REFERRAL;
  }
  return { source, medium };
}

function setCookie(name, value, days) {
  const expires = new Date();
  expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000);
  document.cookie = `${name}=${encodeURIComponent(
    value
  )}; expires=${expires.toUTCString()}; path=/; SameSite=None; Secure`;
}

function setCookieExpInSeconds(name, value, seconds) {
  const expires = new Date();
  expires.setTime(expires.getTime() + seconds * 1000); // Expire in X seconds
  document.cookie = `${name}=${encodeURIComponent(
    value
  )}; expires=${expires.toUTCString()}; path=/; SameSite=None; Secure`;
}

function getCookie(name) {
  const cookieArr = document.cookie.split(";");
  for (let i = 0; i < cookieArr.length; i++) {
    const cookiePair = cookieArr[i].split("=");
    if (name === cookiePair[0].trim()) {
      return decodeURIComponent(cookiePair[1]);
    }
  }
  return null;
}

function getInitialData(eventTrigger, eventData = {}) {
  return {
    event_type: eventTrigger,
    time: new Date().toISOString(),
    ...eventData,
  };
}

function collectAcquisitionData(eventTrigger, eventData) {
  let data = getInitialData(eventTrigger, eventData);

  // Capture UTM Parameters
  Object.values(UTM_PARAMS).forEach((param) => {
    const value = getQueryParam(param);
    if (value) {
      data[param] = value;
    }
  });

  let hasClickId = false;

  // Capture Click IDs (gclid, msclkid, etc.)
  Object.values(CLICK_IDS).forEach((clickId) => {
    const value = getQueryParam(clickId);
    if (value) {
      data[clickId] = value;
      hasClickId = true;

      // Special handling for click IDs
      if (clickId === CLICK_IDS.GOOGLE) {
        data[UTM_PARAMS.SOURCE] = SOURCES.GOOGLE;
        data[UTM_PARAMS.MEDIUM] = MEDIUMS.CPC;
      } else if (clickId === CLICK_IDS.MICROSOFT) {
        data[UTM_PARAMS.SOURCE] = SOURCES.MICROSOFTADS;
        data[UTM_PARAMS.MEDIUM] = MEDIUMS.CPC;
      } else if (clickId === CLICK_IDS.FACEBOOK) {
        data[UTM_PARAMS.SOURCE] = SOURCES.FACEBOOK;
        data[UTM_PARAMS.MEDIUM] = MEDIUMS.PAID;
      } // Add similar logic for other click IDs if necessary
    }
  });

  // Allow utm_medium to be any value
  const utmMediumFromURL = getQueryParam(UTM_PARAMS.MEDIUM);
  data[UTM_PARAMS.MEDIUM] = utmMediumFromURL
    ? utmMediumFromURL
    : MEDIUMS.REFERRAL;

  // If no click ID, fall back to referrer logic
  if (!hasClickId) {
    if (!data[UTM_PARAMS.SOURCE] || !data[UTM_PARAMS.MEDIUM]) {
      const referrerData = getReferrerSourceMedium();
      data[UTM_PARAMS.SOURCE] = referrerData.source;
      data[UTM_PARAMS.MEDIUM] = referrerData.medium;
    }
  }

  // Store data in cookies (First-touch attribution)
  if (!getCookie(UTM_PARAMS.SOURCE) && !getCookie(UTM_PARAMS.MEDIUM)) {
    Object.keys(data).forEach((key) => {
      //   setCookie(key, data[key], COOKIE_EXPIRATION_DAYS);
      setCookie(key, data[key], 120);
    });
  }

  //console.log("data before", data);
  // Now, ensure data always includes the newest cookies before sending
  COOKIE_NAMES.forEach((cookieName) => {
    const cookieValue = getCookie(cookieName);
    if (cookieValue) {
      data[cookieName] = cookieValue;
    }
  });

  //console.log("data after", data);

  // Only send data to the backend when the user is on the /contact-us page
  if (window.location.pathname.includes("contact")) {
    fetch(CONVERSION_DEV_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Api-Key": HOLYCODE_API_KEY,
      },
      body: JSON.stringify(data),
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error("Failed to send data to backend");
        }
        return response.json();
      })
      .then((result) => {})
      .catch((error) => {
        console.error("Error sending data to backend:", error);
      });
  }
}

document.addEventListener("DOMContentLoaded", () => {
  collectAcquisitionData(EVENT_TYPE.CONTACT_FORM_VIEW, {
    name: EVENT_TYPE.CONTACT_FORM_VIEW,
  });
});
